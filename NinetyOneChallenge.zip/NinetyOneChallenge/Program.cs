﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Runtime.Remoting.Messaging;

namespace NinetyOneChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            // I made the assumption that the input is from a textfile with text already in it. 
            // The notes stated that The application should include a way to input data via a plain-text file
            // I assumed that the different numbers would be filled into the textfile
            // I ran out of time and as a result was not able to display invalid number as output. The application will work for all number not greater than a billon
            // and all valid numbers. All invalid numbers will not display correctly

            // To run application, place any input in a textfile and insert the filepath into the variable string FilePath
            // Assigning textfile location containing test input
            string filePath = @"C:\Users\moone\OneDrive\Desktop\Job Applying\Ninety One\NinetyOneChallenge.txt";

            // Create list for current input
            List<string> lines = new List<string>();
            lines = File.ReadAllLines(filePath).ToList();
            // List for matched values
            List<string> matchlist = new List<string>();

            // Regex pattern to seperate numbers from the string
            Regex regex = new Regex(@"\d+");

            // I unfortunately ran out of time and was unable to validate the the numbers as seen by the commented out code below

            // regex for invalid number
           // Regex SpaceReg = new Regex(@"\s");
            //Regex ComReg = new Regex(@"\,");
            //Regex HashReg = new Regex(@"#");

            // Use regex to match values in lines list and then add those values to matchlist 
            foreach (string line in lines)
            {
                //if (SpaceReg.IsMatch(line))
                //{

                //}
                //if (ComReg.IsMatch(line))
                //{

                //}
                //if (HashReg.IsMatch(line))
                //{

                //}

                if (regex.IsMatch(line))
                {
                 matchlist.Add(regex.Match(line).Value);
                }
            }

            // Get matched items from matchlist and convert them to word equilvalent
            foreach (string item in matchlist)
            {
                // Convert input to int
                long FileInput = Convert.ToInt64(item);
                // Call method for conversion
                string convert = ConvertNumbertoWords(FileInput);
                // Convert input to string to be able to assign it to converted numbers (String)
                string NewFileInput = Convert.ToString(FileInput);
                // assign input
                NewFileInput = convert;

                // Write output
                Console.WriteLine(NewFileInput);

            }
            Console.ReadLine();
        }

       
        public static string ConvertNumbertoWords (long FileInput)
        {
            // conversion to zero and minus
            if (FileInput == 0)
                return " zero ";

            if (FileInput < 0)
                return "minus " + ConvertNumbertoWords(Math.Abs(FileInput));

            // assign word variable
            String Word = "";

            // conversion of numbers
            // billions
            if ((FileInput / 1000000000) > 0)
            {
                Word += ConvertNumbertoWords(FileInput / 1000000000) + " billion ";
                FileInput %= 1000000000;
            }

            // millions
            if ((FileInput / 1000000) > 0)
            {
                Word += ConvertNumbertoWords(FileInput / 1000000) + " million ";
                FileInput %= 1000000;
            }

            // thousands
            if ((FileInput / 1000) > 0)
            {
                Word += ConvertNumbertoWords(FileInput / 1000) + " thousand ";
                FileInput %= 1000;
            }

            // hundreds
            if ((FileInput / 100) > 0)
            {
                    Word += ConvertNumbertoWords(FileInput / 100) + " hundred ";
                    FileInput %= 100;
            }
            
            // Inserting and and '-'
             if (FileInput > 0)
            {
                if (Word != "") Word += "and ";

                // put words in array for anything less than 100
                var Units = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
                var Tens = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

                // less than 20 - words
                if (FileInput < 20) Word += Units[FileInput];
                else
                {
                    Word += Tens[FileInput / 10];

                    if ((FileInput % 10) > 0) Word += "-" + Units[FileInput % 10];
                }

          

                
            }
            return Word;
        }

    }

}
